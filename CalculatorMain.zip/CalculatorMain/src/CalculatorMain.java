
public class CalculatorMain {
    public static void main(String[] args) {

        GetInfo getInfo = new GetInfo();
        getInfo.printInfo();

    }
}
