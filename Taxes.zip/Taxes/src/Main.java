import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Witaj w programie liczącym wysokość podatku do zapłaty.");
        System.out.print("Proszę o podanie wysokości dochodu: ");
        double BaseToTax = scanner.nextDouble();

        System.out.println("Podana wartość dochodu to: "+BaseToTax);

        TaxCounting taxCounting = new TaxCounting();
        double TaxToPay = taxCounting.TaxToPay(BaseToTax);
        
        System.out.println("Należna wartość podatku do zapłaty to: "+TaxToPay);

    }
}
