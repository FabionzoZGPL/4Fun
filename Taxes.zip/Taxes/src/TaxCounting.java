class TaxCounting {

  double TaxToPay(double BaseToTax) {
        double taxToPay;
        if (BaseToTax < 85_528) {
            taxToPay = BaseToTax * 0.18 - 556.02;
            if(taxToPay<=0){
                taxToPay = 0;
            }
            return taxToPay;
        } else {
            taxToPay = (BaseToTax - 85_528) * 0.32 + 14_839.02;
            return taxToPay;

        }
    }
}