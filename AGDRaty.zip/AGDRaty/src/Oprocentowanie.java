 class Oprocentowanie {

    double oprocentowanieRat (int ratyAGD) {

        if(ratyAGD <=24 && ratyAGD >=13) {
            return 5.0;

        } else {
            return ratyAGD <=12 ? 2.5:10;
        }
    }

    void printInfo( double oprocentowanieRat){
        System.out.println("Oprocentowanie w skali roku wynosi "+oprocentowanieRat);
    }

    double wysokośćRaty (int ratyAGD, double wartośćAGD, double oprocentowanieRat){
        double wysokośćKredytu = wartośćAGD*(1+oprocentowanieRat/100);
        double rataMiesięczna = wysokośćKredytu/ratyAGD;
        return rataMiesięczna;
    }

    void printInfo2( double rataMiesieczna){
        System.out.print("Twoja rata miesięczna wynosi: ");
        System.out.printf("%.2f", rataMiesieczna);
    }
}
