import java.util.Scanner;

public class Main{
    public static void main(String[] args) {

        System.out.println("Witaj w programie umożliwiającym wyliczenie wysokości rat.");
        System.out.print("Proszę o podanie wartości sprzętu AGD (wartość od 100 zł do 100_000 zł).");

        Scanner scanner = new Scanner(System.in);
        double wartoscAGD = scanner.nextDouble(); //pozyskanie wartości sprzętu do kredytu
        System.out.println("Wartość sprzętu do wyliczeń wynosi: "+wartoscAGD);

        System.out.print("Proszę o podanie ilości rat ( wartość od 6 do 48).");
        int ratyAGD = scanner.nextInt(); //pozyskanie ilości rat kredytu

        System.out.println("Ilość rat kredytu wynosi "+ratyAGD);

        Oprocentowanie oprocentowanie = new Oprocentowanie(); // wyświetli informację o grupie oprocentowania
        oprocentowanie.printInfo(oprocentowanie.oprocentowanieRat(ratyAGD));

        oprocentowanie.printInfo2(oprocentowanie.wysokośćRaty(ratyAGD,wartoscAGD,
                oprocentowanie.oprocentowanieRat(ratyAGD)));


    }
}
